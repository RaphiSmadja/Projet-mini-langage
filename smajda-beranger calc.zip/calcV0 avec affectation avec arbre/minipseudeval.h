#ifndef MINIPSEUDEVAL
# define MINIPSEUDEVAL

double eval(Node *node);

#endif
